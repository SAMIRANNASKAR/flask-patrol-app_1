from flask import Flask, render_template, request, jsonify, send_file
import sqlite3
from datetime import datetime
import os
from openpyxl import Workbook, load_workbook

app = Flask(__name__)

# Initialize DB
def init_db():
    conn = sqlite3.connect('patrol.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guard_id TEXT,
            checkpoint TEXT,
            scan_time TEXT,
            location TEXT
        )
    ''')
    conn.commit()
    conn.close()

def update_excel(guard_id, checkpoint, scan_time, location):
    file_path = 'patrol.xlsx'

    if not os.path.exists(file_path):
        wb = Workbook()
        ws = wb.active
        ws.append(["Guard ID", "Checkpoint", "Scan Time", "Location"])
    else:
        wb = load_workbook(file_path)
        ws = wb.active

    ws.append([guard_id, checkpoint, scan_time, location])
    wb.save(file_path)

init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit_scan', methods=['POST'])
def submit_scan():
    data = request.get_json()
    guard_id = data.get('guard_id')
    checkpoint = data.get('checkpoint')
    location = data.get('location', 'Unknown')
    scan_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect('patrol.db')
    c = conn.cursor()
    c.execute("INSERT INTO scans (guard_id, checkpoint, scan_time, location) VALUES (?, ?, ?, ?)",
              (guard_id, checkpoint, scan_time, location))
    conn.commit()
    conn.close()

    update_excel(guard_id, checkpoint, scan_time, location)

    return jsonify({"status": "success", "time": scan_time})

@app.route('/download_excel')
def download_excel():
    path = 'patrol.xlsx'
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    else:
        return "Excel file not found.", 404

@app.route('/admin')
def admin_dashboard():
    conn = sqlite3.connect('patrol.db')
    c = conn.cursor()
    c.execute("SELECT guard_id, checkpoint, scan_time, location FROM scans ORDER BY scan_time DESC")
    logs = c.fetchall()
    conn.close()
    return render_template('admin.html', logs=logs)

if __name__ == '__main__':
    app.run(debug=True)